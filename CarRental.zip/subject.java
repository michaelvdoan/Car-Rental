import java.util.Map;
import java.util.Random;
import java.util.Vector;
import java.io.*;
import java.util.HashMap; 
//Kevin Huynh and Michael Doan
//LATE PASS

public abstract class subject {
    public abstract void add_customer(customer c);
    public abstract void remove_customer(customer c);
    public abstract void notify_customer(customer c);
}